Infinity Player PC v73 - Microphone Stop and Save Fix

- Audio Description and Alternate Track Selector lists embedded audio tracks, identifies likely descriptive tracks, plays the selected track through MPV and can extract it to MP3.
- Subtitle and Transcript Tools lists embedded subtitle languages and titles, opens subtitle text in the accessible reader and exports SRT or clean TXT.
- Audio Recording and Editing reliably discovers Windows microphones, safely handles device names containing spaces or symbols, records with an accessible duration prompt and Escape cancellation, explains microphone permission or disconnection errors, and provides trim, loudness normalization and silence removal.
- Microphone recording now uses the proven NAudio WaveIn compatibility backend, lists every active recording device and opens the selected microphone through the Windows audio mixer.
- Headset, USB, external and microphone-array devices now negotiate mono or stereo automatically across common sample rates instead of forcing every microphone to accept one fixed format.
- Pressing Escape during recording now asks the microphone helper to stop cleanly, finalize the WAV file and save the MP3 instead of terminating the helper before it can write the recording.
- The microphone helper and its library are staged together in a short temporary path, so portable folders with long names do not break recording.
- Native recording processes now have enforced cancellation and timeout cleanup so a failed attempt cannot keep the microphone locked. After saving, Recording Complete offers Play Recording, Record Again and Back.
- The portable archive is packaged flat to prevent duplicated extraction folders from exceeding the Windows process path limit and silently blocking the microphone helper.
- Custom TV and radio playlists now offer Browse All Channels or Find and Browse Playable Channels. Their channel lists include fuzzy search and group-title category browsing.
- Reader, conversion, audiobook, Audioboom and AudioVault worker failure paths were audited so accessible errors are spoken instead of internal PowerShell command messages.
- Media track, subtitle and metadata screens now reject incomplete probe rows safely instead of risking an invalid list access.
- Media Chapters and Metadata provides a standalone accessible view of title, artist, album, duration, chapters, audio tracks and subtitle tracks.
- Playlist Creator and Converter creates M3U playlists from media folders, plays M3U/PLS files and converts PLS to M3U.
- All new proprietary worker logic remains protected inside data.dat in the public package.

Infinity Player PC v63 - Audiobook Logic Audit

- Continue Last Audiobook now restores the complete folder-book queue, current chapter and saved time instead of reopening only one chapter file.
- Folder chapters use natural numeric ordering, so Chapter 2 appears before Chapter 10 even without leading zeroes.
- Folder audiobooks automatically continue to the next chapter without changing the normal Local Player auto setting.
- Position is saved on previous chapter, next chapter, Escape, Back and player-window close, in addition to the five-second safety interval.
- Bookmarks can now be removed from the accessible bookmark list.
- Missing or moved last-book files and empty saved folders produce clear spoken errors.

Infinity Player PC v62 - Accessible Audiobook Library

- Media Accessibility now includes an accessible audiobook library for individual files and chapter folders.
- MP3, M4B, M4A, AAC, OGG, Opus, FLAC, WAV and WMA audiobooks are supported.
- Embedded M4B/media chapters, title, author and duration are read through the bundled FFprobe component.
- Playback position is saved automatically and Continue Last Audiobook resumes it.
- Press B inside the Audiobook Player to save a named bookmark at the current time.
- Audiobook bookmarks reopen the exact saved time, and the sleep timer supports 15, 30, 45, 60 or 90 minutes.
- Audiobook playback keeps the existing accessible playback shortcuts while remaining separate from normal Local Player state.

Infinity Player PC v61 - Protected Runtime Data

- Proprietary PowerShell worker logic is stored in encrypted data.dat instead of being distributed as readable scripts.
- Every protected worker has a SHA-256 integrity value checked before use. A damaged or incorrect container is rejected.
- Protected workers are materialized only in a session-specific runtime folder and removed during normal application exit.
- Public packages still contain required third-party executables and DLLs because Windows must load them directly and their licenses require proper notices.

Infinity Player PC v60 - Shorts Results and Comments Fix

- YouTube Shorts now use paginated search and honor the configured video result limit instead of stopping at a tiny Shorts shelf.
- Shorts results are limited to videos up to three minutes and retain normal video playback, metadata, downloads, and position labels.
- Press Tab on a selected YouTube video result to open its comments. A Comments for selected video button is also available as an accessible fallback.

Infinity Player PC v59 - YouTube Category Browser

- Search on YouTube now opens Search YouTube or Browse Categories instead of mixing category choices into the query form.
- Search YouTube contains query, Videos/Playlists/Channels and sorting only.
- Browse Categories opens Popular, Shorts, Music, Gaming, News, Sports, Education, Entertainment, Science and Technology, Film and Animation, How-to and Style, or Travel and Events directly without asking for a query.
- Popular and topic categories prioritize view count, News prioritizes upload date, and Shorts uses relevance with YouTube's short-duration filter.
- Shorts remains eligible up to three minutes under YouTube's current rules and is no longer presented as a search type.

Infinity Player PC v58 - YouTube Shorts Search

- Search on YouTube now offers Videos, Shorts, Playlists and Channels as separate result types.
- Shorts search combines the YouTube short-duration filter with the Shorts topic marker instead of mixing ordinary long videos.
- Shorts play in the same accessible player and retain Space details, Tab comments, downloads and favorites behavior.
- YouTube supplies Shorts in relevance order; unsupported alternate sorting is automatically changed to Relevance with speech feedback.

Infinity Player PC v57 - Media Conversion and YouTube Search Upgrade

- Conversion is organized by purpose instead of mixing audio, video and images in one format list.
- One-file and recursive folder converters create MP3 64-320 kbps, OGG 96-256 kbps, M4A AAC 128-256 kbps, FLAC or WAV audio from playable audio/video sources.
- Image-to-document and PDF-to-document converters create TXT, accessible HTML or valid DOCX through offline English/Hindi OCR.
- Recursive folder conversion excludes Infinity Player's Converted Files output tree to prevent accidental repeat conversion.
- YouTube search includes result type, category topic and Relevance, Upload Date, View Count or Rating sorting.
- Tab on a focused YouTube video result opens up to ten public top-level comments; replies are skipped for speed. Comments can be spoken or copied.
- Shift+Tab remains available for ordinary result-window control navigation.

Infinity Player PC v56 - Reading OCR Audit and Complete Conversion

- Reading and OCR native-tool warnings no longer become false application errors.
- Image OCR was verified against a generated English text fixture and DAISY parsing was regression-tested.
- Pronunciation Dictionary removes entries from the visible list immediately.
- File and Folder Conversion has no locked entries.
- Six accessible encoding presets provide voice MP3, standard/high MP3, FLAC and compatible/small MP4 output.
- OCR Export creates real TXT, HTML or valid Microsoft Word DOCX files from images and PDFs.
- Conversion History is an accessible navigable list with Space-to-read and copy support.
- Subtitle conversion remains grouped under Media Accessibility instead of being duplicated here.

Infinity Player PC v55 - Accessibility Hub Menu Cleanup

- Overlapping planned tools are grouped before implementation so one job does not appear under several names.
- Subtitle reading, viewing, generation and conversion are grouped as Subtitle and Transcript Tools.
- Recording, trimming, silence removal and normalization are grouped as Audio Recording and Editing.
- Vision, productivity, language and accessibility-profile roadmaps use focused tool suites instead of duplicate entries.
- Image Resize and Rotate now share one accessible Image Tools submenu while preserving both existing actions.
- Reading and OCR Tools remains complete and unchanged.

Infinity Player PC v54 - Complete Reading and OCR Menu

- Reading and OCR Tools is reorganized into four clear working areas without duplicate entries.
- Books and Document Reader now contains normal documents, image OCR, scanned PDF OCR, DAISY books, web articles, clipboard reading, recent documents and bookmarks.
- Camera Text Scanner contains printed-text scanning and experimental handwriting scanning.
- Table and Form Reader preserves PDF layout or uses table-focused image OCR.
- Reading Preferences offers short, standard and long focus sections plus a user pronunciation dictionary.
- Custom pronunciation replacements apply when a reader section is spoken with Space.
- Low-vision themes remain correctly placed in Accessibility Settings and Profiles rather than being duplicated in OCR.

Infinity Player PC v51 - Camera Text Scanner

- Screen and active-window OCR were removed because they duplicated dedicated screen-reader tools and were not reliable enough.
- Image-file OCR and scanned-PDF OCR remain available in Books, Documents and Images.
- Camera Text Scanner lists compatible Windows webcams and recognizes a printed page in English and Hindi.
- Camera frames are temporary and are deleted immediately after recognition.
- Camera discovery uses captured process output, so FFmpeg's expected device-list exit no longer appears as an application error.
- Camera discovery accepts both DirectShow `(video)` and `(none)` device labels even when FFmpeg omits its section headings.

Infinity Player PC v48 - Reading and OCR Tools Phase Two

- DAISY Book Reader opens DAISY ZIP packages, OPF/XML/NCX package files and HTML books, preserving package spine order when available.
- Web Article Reader accepts an HTTP or HTTPS address, removes scripts, styles and page markup, and prefers article or main content.
- Image-file OCR and scanned-PDF OCR use bundled English/Hindi recognition.
- Web articles, clipboard text and temporary screen captures no longer create broken file entries in Recent Documents.

Infinity Player v33 - Proprietary Public Release Licensing

Infinity Player is now documented as closed-source proprietary software owned
by Deepak Tamang. The package includes LICENSE.txt, EULA.txt, and
THIRD_PARTY_NOTICES.txt, while the Credits screen announces the copyright and
points users to those files. Third-party GPL and permissive components retain
their own licenses. Public releases must distribute only the portable package,
not the private Full Source archive.

Infinity Player v32 - Multilingual TV Feed Matching

TV country and language playlists now match the base channel ID instead of
requiring identical feed suffixes. IDs such as DisneyChannel.in,
DisneyChannel.in@SD and DisneyChannel.in@HD are treated as the same channel.
This prevents multilingual Indian channels from disappearing from Hindi merely
because the country and language playlists describe different feed variants.
Every matching SD/HD stream is still passed through the existing ffprobe check,
so only streams that are currently playable appear in the final list.

Infinity Player v31 - Correct Native Controller Launch

Fixed the actual portable-app controller launch bug: its quoted queue-directory
argument ended in a backslash, which escaped the closing quote for a Windows
EXE and prevented the native controller from receiving separate arguments.
That made v30 silently use the slower fallback despite the controller passing
isolated tests. Queue paths no longer end in a backslash. The same native EXE
now handles both persistent control and one-shot fallback, so the two MPV
PowerShell control scripts are removed from the source and portable package.

Infinity Player v30 - Native Instant Controls and Faster YouTube Start

Replaced the PowerShell-based live MPV controller with a compiled Windows
controller executable. It stays connected directly to MPV, processes control
commands every 5 ms, and has no PowerShell startup cost. An end-to-end test
confirmed pause, mute and Quit; MPV exited in under 200 ms. The ready handshake
and safe one-shot fallback remain. YouTube and YouTube Music now go directly to
MPV's single yt-dlp resolution path instead of first resolving through yt-dlp,
trying NVGT streaming, and then sometimes resolving again through MPV. Local
files continue using the fast NVGT backend unchanged.

Infinity Player v29 - Safe MPV Controller Handshake

Fixed the v28 regression where the app could assume its fast MPV controller
was running even when the controller had not connected, leaving every control
command queued and allowing audio to continue after exiting the player. The
controller now creates a ready signal only after a real named-pipe connection.
Infinity Player waits for that signal before enabling fast controls; if it is
not received, playback automatically retains the proven one-shot IPC fallback.
The controller also has a bounded connection timeout and removes its ready
signal during a normal shutdown.

Infinity Player v28 - Immediate MPV Command Controller

Online players now start one persistent MPV controller for the lifetime of the
playing item. Space, mute, seek, volume and time commands go through this ready
controller instead of starting a new PowerShell process for every key press.
The controller keeps one MPV named-pipe connection open, ignores unrelated MPV
events while matching command responses, and processes its queue at 10 ms
intervals. A real bundled-MPV queue test processed pause plus the two-property
time request in under 200 ms. The older one-shot IPC worker remains as fallback
if the persistent controller cannot start.

Infinity Player v27 - Responsive Online Controls

MPV control commands such as play, pause, seek, mute and volume are now sent
without blocking the player screen while a separate PowerShell process starts.
The T shortcut requests current time and total duration through one IPC worker
instead of launching two workers consecutively, and reuses the duration for
later readings during the same item. Mute uses the player application's tracked
state, avoiding an extra blocking query before every toggle. Volume Up and
Volume Down now change by 1 at a time in every player instead of 5.

Infinity Player v26 - Local Player Audio Controls

Fixed the NVGT sound-backend volume scale used by Local Player. Local files
now start audible when not muted, M applies the requested mute state, and the
spoken Muted or Unmuted status matches the resulting state. Volume changes now
map the public 0-to-100 setting to NVGT's internal -100-to-0 scale. The same
correction also protects any other playback path that uses NVGT sound directly;
MPV playback remains on its native 0-to-100 scale.

Infinity Player v25 - Broad Audioboom Search

Audioboom search no longer requires an exact programme or episode title.
General searches such as Hindi, Hindi series, Hindi episodes, Hindi stories,
and topic-plus-language searches are expanded into several Audioboom searches.
Duplicate results are removed and the original Audioboom relevance order is
preserved. Language words are search hints and no longer reject a result just
because an Audioboom RSS feed has missing or inaccurate language metadata.

Infinity Player v24 - Simple Direct Audioboom Search

Audioboom now opens directly to Search on Audioboom. Language browsing and
category menus have been removed. The search screen has only Series and
Playlists and Single Audio Episodes. Searches use Audioboom results directly;
opening a series shows its episodes, and an episode plays in Infinity Player.
The PowerShell return syntax error seen in language/category browsing is fixed.
The verified playback, seek, time, mute and volume controls from v23 remain.

Infinity Player v18 - Direct Audioboom Catalog, Playback and Downloads

Audioboom results hotfix: every result row now contains stable non-empty fields
so NVGT preserves all columns and displays the list instead of returning to the
menu. Application key, Shift+F10 and right-click now open Audioboom Options on
an episode with Download audio and Copy Audioboom link. The separate Download
button was removed. Empty searches now announce No Audioboom results found.

Audioboom now uses audioboom.com directly instead of indirectly filtering the
Apple podcast directory. Its accessible menu contains Search Podcasts, Search
Episodes and Audio Stories, and Browse Featured Podcasts. Opening a podcast
loads its official Audioboom RSS episodes. Episodes are resolved with yt-dlp's
AudioBoom extractor, play directly in Infinity Player, and can be downloaded
to Downloads\Audioboom with the Download button.

The portable package includes the LibreSSL curl-for-win binary used for reliable
Audioboom catalog pages, its required DLL, and its license. Episode media URLs
and metadata are still resolved by the bundled yt-dlp executable.

Infinity Player v23 - Universal Audioboom Search and Verified Controls

Language-aware queries are broadened before being sent to Audioboom. Searches
such as Hindi story, Hindi stories and Hindi kahani become a broad Hindi query;
Hindi romantic stories becomes Hindi love; equivalent genre expansion applies
to horror, crime, fiction, kids, devotional, comedy, history and poetry. Results
are still checked against the official RSS language code, so broader matching
does not reintroduce unrelated English feeds into Hindi results. This expansion
works in Series and Playlists, Single Audio Episodes, All Results and Browse.

Audioboom and ordinary Podcasts now use MPV for HTTP media so seek, time, mute
and volume controls have one reliable backend. MPV commands wait for the named
pipe response instead of being launched fire-and-forget. M now queries MPV's
actual mute property before toggling, preventing spoken state and real audio
state from becoming reversed. A bundled-MPV test successfully performed a
relative seek, set mute, and read the real mute property back as True.

Previous v22 notes follow.

Infinity Player v22 - Audioboom Typed Search and Language Filtering

Audioboom search now follows the YouTube-style flow: choose Series and
Playlists, Single Audio Episodes, or All Results, then enter the query. Series
results open their official Audioboom RSS episode list; episode results play
directly. Common Kya Woh Sach Tha spelling variants are handled in the Series
search and return both official season channels even during a temporary search
endpoint failure.

Browse by Language now sends the selected language separately from the search
text. Candidate series and episodes are checked against the language code in
their official Audioboom RSS feed, preventing English feeds from being shown as
Hindi merely because their description contains the word Hindi. Forty language
choices and ten story genres remain available.

Previous v21.1 notes follow.

Infinity Player v21.1 - Audioboom Search and Horror Hotfix

Common spellings such as "kya vo such tha", "kya wo sach tha" and the official
"Kya Woh Sach Tha" now resolve to the same Audioboom search. Hindi Horror shows
the two official Audioboom season channels immediately, even when Audioboom's
general search endpoint returns no podcast channels. Live matching results are
still appended when available. The category/search wait window is now long
enough for paginated Audioboom searches on slower connections. Exact worker
tests returned both season channels for the user's spelling and Horror menu.

Previous v21 notes follow.

Infinity Player v21 - Live Audioboom and Shared Player Controls

Audioboom no longer uses a small hand-built story catalog. Browse Stories by
Language offers 40 languages and ten story genres; every selection and Search
All Audioboom queries Audioboom live for both series and individual episodes,
with pagination up to 200 results. Opening a series reads its official RSS feed
and playback resolves the selected Audioboom episode directly.

Audioboom's Kya Woh Sach Tha Season 1 RSS currently contains its own episodes
plus duplicated Season 2 titles. Infinity Player now discovers the sibling
season through Audioboom's own parent catalog and removes the duplicated titles
dynamically. Verified live result: Season 1 shows 20 episodes and the separate
Season 2 feed shows 20. No fabricated Season 3 entry is added; it will appear
when Audioboom itself exposes it through search/catalog results.

MPV controls now use a real Windows named-pipe client instead of attempting to
write to the pipe like an ordinary file. This repairs play/pause, rewind,
forward, mute/unmute, volume, speed and other shared MPV controls for Audioboom,
Podcasts, Television, Radio, YouTube and YouTube Music. T now queries MPV's
actual time-pos and duration properties. Player windows identify Audioboom,
Podcast and YouTube Music instead of always saying YouTube Player. The IPC
helper was tested against the bundled MPV and returned the correct duration.

Previous v20 notes follow.

Infinity Player v20 - Expanded Audioboom Audio Story Catalog

Hindi Audio Stories now follows Audioboom's real catalog more closely. The
menu includes Horror, Romance and Love, Crime and Mystery, Drama and General
Stories, Moral and Kids, Mythology and Devotional, Comedy, Poetry and Shayari,
and All Hindi Audio Stories. Verified official Audioboom series are shown in
their matching categories and live category searches add further available
series and episodes instead of limiting the list to a few hard-coded results.

Ek Kahani Aisi Bhi is correctly listed as the standalone Morning No. 1 episode
that Audioboom publishes. Love Aaj Kal and Bytes on Love are included under
Romance and Love. The Kya Woh Sach Tha seasons remain separate official series.
Category loading now waits long enough for live Audioboom results and keeps the
verified catalog available even if Audioboom search is temporarily unreachable.

Previous v19 notes follow.

Infinity Player v19 - Audioboom Hindi and English Audio Stories

Audioboom now opens with three simple choices: Hindi Audio Stories, English
Audio Stories, and Search Audioboom. Each language has clear story categories.
Verified Hindi series are placed directly in the appropriate category, including
both seasons of Kya Woh Sach Tha, Kidoo Stories, Ramayan Hindi, Mahabharat Hindi,
Devi Katha, Shani Dev, and Shivgatha. Opening a series lists its real Audioboom
episodes; opening an episode plays it in Infinity Player.

Search Audioboom searches both series and individual episodes. On an episode,
press the Application key or Shift+F10 to download its audio or copy its link.
Audioboom supplies individual episode audio files and RSS series rather than ZIP
archives, so Downloads\Audioboom contains the downloaded episode media files.

Previous v17 notes follow.

Infinity Player v17 - Spotify and Audioboom

The main menu now includes Spotify and Audioboom. Audioboom search identifies
Audioboom-hosted public podcast feeds and plays their episode audio directly in
Infinity Player. Spotify provides accessible track, album and playlist search,
opens album/playlist tracks, and starts playback on an active Spotify Connect
device. If no active device is available it opens the selected item in the
official Spotify application.

Spotify requires a developer Client ID and Client Secret plus the Redirect URI
http://127.0.0.1:8888/callback/ in the developer dashboard. Use Spotify Setup,
then Login to Spotify. Spotify music is DRM protected and is not sent through
MPV; official Spotify playback is used. Spotify currently requires Premium for
Web API playback control. Credentials and tokens are protected for the current
Windows user with Windows DPAPI.

Previous v16 notes follow.

Infinity Player v16 - AudioVault and YouTube Music Playback Fix

The main menu now includes an accessible native AudioVault section with Login,
Search Movies, Search Shows, Recent Movies, Recent Shows, Download and Play,
and Logout. AudioVault credentials are stored under the player root in data;
the password is protected for the current Windows user with Windows DPAPI.
Downloads are saved under Downloads\AudioVault. YouTube Music now resolves real
YouTube video results through the same proven search and playback path used by
the main YouTube section, fixing the invalid ytsearch pseudo-URL MPV failure.

AudioVault depends on the current AudioVault website layout and requires a
valid account. If the website changes its login or catalog HTML, the worker may
need a small parser update.

Podcast link-copy fix: pressing L while a podcast episode is playing now copies
that episode's original audio enclosure URL instead of a stale shared YouTube
link.

Previous v15 notes follow.

Infinity Player v15 - Podcasts and YouTube Music

The main menu now contains Podcasts and YouTube Music. Podcast search uses the
public iTunes podcast directory, opens the publisher's real RSS feed, lists up
to 200 episodes and plays each feed's direct audio enclosure. YouTube Music
uses dedicated music-oriented YouTube search and the existing yt-dlp playback
engine. The experimental Crunchyroll integration has been removed.

Previous update notes follow.

Close Infinity Player. Extract Infinity_Player_v8_Update.zip into your existing
working Infinity Player folder. Replace player.exe, bin/yt_worker.ps1 and matching
library files when asked. Do not delete your existing folder.
Keep your existing yt-dlp.exe, mpv.exe, ffmpeg.exe, ffprobe.exe, favorites,
settings, and downloads. This update ZIP is not a standalone portable player.

Changes:
- Empty channel/playlist extraction automatically retries using the previous
  non-lazy extraction mode. Successful normal loading still opens at 20 items.
- Retry output is still read progressively; only the compatibility extractor's
  initial response can take longer.
- Reset retry state fully so old cursors and duplicate tracking cannot discard
  the new attempt's videos. Parent search and child video lists stay separate.
- Avoid appending /videos twice to a channel URL already ending in /videos.
- When both extraction attempts and the page fallback fail, show the actual
  error instead of simply saying No results found. The latest failure is saved
  in runtime/last_collection_error.txt (one overwritten diagnostic file).

Verification:
Release compilation succeeded. All 28 streaming regression checks passed.
A controlled worker test forced the first playlist and channel attempts to fail;
both retried successfully and returned 20 videos before the worker finished.
Live YouTube and NVDA interaction were not verified here: network access to
YouTube was blocked by Windows socket permissions (WinError 10013).
The exact cause of the user's live failure is not yet confirmed.

Please test Search > Playlists > Enter, Search > Channels > Enter, and Saved
Playlists. Try playing an early result while later results load, and Escape back.
If loading still fails, send runtime/last_collection_error.txt and the name of
the channel or playlist you tried. Do not send cookies or account credentials.

Infinity Player v41 - AudioVault PC Integration

AudioVault is available inside Entertainment with Search Movies, Search Shows,
Browse Movies, Browse Shows, Recent Movies, Recent Shows, Login or Change
Account, and Logout. Catalog browsing remains accessible before login. An
AudioVault account is required when downloading an item. Downloads are stored
under Downloads\AudioVault and start in the Infinity Player. ZIP season
downloads are extracted automatically and the first supported media item is
opened. Passwords are protected for the current Windows account.

Infinity Player v42 - AudioVault Registration and Season Folders

An AudioVault account can now be created from inside Infinity Player. Selected
catalog results expose Play or Open Folder and Download Complete File or ZIP
actions; the Application key and Shift+F10 open the same action menu. TV season
ZIP files are downloaded once, extracted, cached, and presented as accessible
episode folders. Opening an episode uses the normal local playback controls.

Infinity Player v43 - AudioVault Download Progress

While an AudioVault item is downloading, press Space to hear its percentage,
downloaded and total MB or GB, and average transfer speed. Extraction status is
also announced. AudioVault supplies seasons as compressed ZIP downloads, so a
season is downloaded once, extracted, cached, and then opened automatically as
an accessible episode folder. Cached seasons reopen without another download.

Infinity Player v44 - AudioVault Online Playback

Play Online for AudioVault movies and single audio items now passes the signed-in
AudioVault session to MPV and does not save the item as a permanent download.
Download remains a separate explicit action. Shows supplied by AudioVault as one
compressed ZIP cannot expose independently streamable episode URLs. Their menu
therefore says Download ZIP and Open Episode Folder until cached, then changes
to Open Downloaded Episode Folder and never downloads that season again.

Infinity Player v45 - Experimental Remote ZIP Episodes

For AudioVault shows, Open Folder reads the ZIP directory using authenticated
HTTP byte ranges without downloading the complete season. Episodes appear as an
accessible list. Play Online streams and decompresses only the selected ZIP
entry through a local loopback proxy without saving it. The episode action menu
also offers Download This Episode. Complete ZIP download remains separate. If
the server refuses byte ranges or uses an unsupported ZIP method, the player
reports that clearly instead of silently downloading the complete archive.
Infinity Player PC v47 - Menu Cleanup and Clipboard Reader

- Entertainment remains the single entry point for the complete Local Media Player.
- Favorites > Local Favorites now opens only saved local files and folders instead of opening the complete Local Player a second time.
- Accessibility Hub > Reading and OCR Tools > Clipboard Reader is now available.
- Clipboard text opens in the accessible reader with paragraph navigation, Space reading, Find, copy, bookmarks and saved reading position.
Infinity Player Manual Premium System
-------------------------------------
The main menu now includes Premium Membership. Users can review the 1, 2, 3,
6, and 12 month plans, enter their registered name, copy a name-and-installation-bound request code, and activate
an approved offline license key. Registration now requires the exact customer
name contained in the original request. Premium status includes that
name, the selected plan and remaining days. File and Folder Conversion, Media
Accessibility, Camera Text Scanner, Table and Form Reader, and advanced reading
preferences are Premium. The core Books and Document Reader remains Free.

Payment is not collected by this build. The private owner-only key generator
must be used only after Deepak Tamang verifies payment. See
PREMIUM_MANUAL_SYSTEM.txt for the exact customer and owner workflow.

When Premium is active, the membership menu changes to an account view showing
the registered name, current plan and remaining days. Registration and the
technical installation-ID option are hidden. Renewal and plan changes are kept
inside one Renew or Upgrade Premium menu.

Offline License Management v2 adds Windows-computer binding, signed clock
rollback detection, seven-day and one-day expiry warnings, renewal after the
existing paid expiry, and accessible issued-customer records in the private
owner generator. Reliable remote revoke and device transfer remain reserved
for the future membership server.

Premium recovery is also stored outside the portable application folder in the
current user's Local AppData. Deleting and downloading Infinity Player again on
the same Windows account and computer restores a still-valid license
automatically. The recovered key remains hardware-bound and is rejected on a
different computer.
